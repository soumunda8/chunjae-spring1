package kr.co.teaspoon.util;

public class SampleInterceptor {
}
